﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
        static double Determinant2DMatrix(double[,] matrix)
        {
            if (matrix.GetLength(0) != matrix.GetLength(1))
            {
                Console.WriteLine("Invalid dimension, determinant is not defined in a non-square matrix");
                return -111;
            }
            double determinant = (matrix[0,0] * matrix[1,1]) - (matrix[1,0] * matrix[0,1]);
            return determinant;
        }
        static double Determinant3DMatrix(double[,] matrix)
        {
            if (matrix.GetLength(0) != matrix.GetLength(1))
            {
                Console.WriteLine("Invalid dimension, determinant is not defined in a non-square matrix");
                return -111;
            }

            double[,] matrix1 = { {matrix[1,1] , matrix[1,2]} ,
                                 {matrix[2,1] , matrix[2,2]} };
            double[,] matrix2 = { {matrix[1,0] , matrix[2,1]} ,
                                 {matrix[2,0] , matrix[2,2]} };
            double[,] matrix3 = { {matrix[1,0] , matrix[1,1]} ,
                                 {matrix[2,0] , matrix[2,2]} };

            double determinant = (matrix[0, 0] * Determinant2DMatrix(matrix1)) - (matrix[0, 1] * Determinant2DMatrix(matrix2)) + (matrix[0, 2] * Determinant2DMatrix(matrix3));
            return determinant;
        }
    }
}
